"""
URL configuration for smartconnect project.
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework.decorators import api_view
from rest_framework.response import Response

@api_view(['GET'])
def api_info(request):
    """Endpoint informativo de la API"""
    return Response({
        "autor": ["Tu Nombre Completo"],
        "asignatura": "Programación Back End",
        "proyecto": "SmartConnect - Sistema de Control de Acceso Inteligente",
        "descripcion": "API RESTful para gestionar sensores RFID, usuarios, departamentos, eventos de acceso y control de barreras",
        "version": "1.0"
    })

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/info/', api_info, name='api-info'),
    path('api/auth/', include('rest_framework.urls')),
    path('api/', include('api.urls')),
]
